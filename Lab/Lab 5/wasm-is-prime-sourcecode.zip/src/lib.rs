mod utils;

use wasm_bindgen::prelude::*;
use prime_tools::*;

// When the `wee_alloc` feature is enabled, use `wee_alloc` as the global
// allocator.
#[cfg(feature = "wee_alloc")]
#[global_allocator]
static ALLOC: wee_alloc::WeeAlloc = wee_alloc::WeeAlloc::INIT;

#[wasm_bindgen]
extern {
    fn alert(s: &str);
}

#[wasm_bindgen]
pub fn greet() {
    alert("Hello, wasm-is-prime! ©Zhaoyi");
}

#[wasm_bindgen]
pub fn CheckPrime(s: &JsValue) {
    let mut input: String = s.as_string().unwrap();
    if is_prime(input) {
        alert("Input is Prime");
    } else {
        alert("Input is NOT Prime");
    }
}
pub fn is_prime(s: String) -> bool {
    let input: u32 = s.trim().parse().expect("Cannot parse");
    is_u32_prime(input)
}
