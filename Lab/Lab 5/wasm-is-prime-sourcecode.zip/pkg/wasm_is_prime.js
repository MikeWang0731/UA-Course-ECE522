import * as wasm from "./wasm_is_prime_bg.wasm";
export * from "./wasm_is_prime_bg.js";