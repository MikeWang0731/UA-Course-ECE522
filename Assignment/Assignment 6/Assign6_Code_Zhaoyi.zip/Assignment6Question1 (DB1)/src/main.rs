use bcrypt::{DEFAULT_COST, hash, verify, BcryptError};
use sqlite::Error as SqErr;
use sqlite::State;

#[derive(Debug)]
pub enum UBaseErr {
    DbErr(SqErr),
    HashError(BcryptError),
}

pub struct UserBase {
    fname: String,
}

impl From<SqErr> for UBaseErr {
    fn from(s: SqErr) -> Self {
        UBaseErr::DbErr(s)
    }
}

impl From<BcryptError> for UBaseErr {
    fn from(b: BcryptError) -> Self {
        UBaseErr::HashError(b)
    }
}

impl UserBase {
    pub fn clear_database(&self) {
        // Use before thinking!!!
        let connection = sqlite::open("./data/users.db").unwrap();
        connection
            .execute(
                "
        delete from users;
        delete from balance;
        delete from transactions;
        ",
            )
            .unwrap();
    }

    pub fn add_user(&self, u_name: &str, p_word: &str) -> Result<(), UBaseErr> {
        let conn = sqlite::open("./data/users.db")?;
        let hpass = bcrypt::hash(p_word, DEFAULT_COST)?;
        // Add info to users
        let mut st = conn.prepare("insert into users(u_name, p_word) values (?,?);")?;
        st.bind(1, u_name)?;
        st.bind(2, &hpass as &str)?;
        st.next()?;
        // init balance with 0
        let mut st2 = conn.prepare("insert into balance(account, balance) values (?,?);")?;
        st2.bind(1, u_name)?;
        st2.bind(2, 0.0)?;
        st2.next()?;

        Ok(())
    }

    pub fn save_money(&self, u_name: &str, amount: f64) -> Result<(), UBaseErr> {
        let current_balance = self.get_balance(u_name);
        let new_balance = amount + current_balance;
        let conn = sqlite::open("./data/users.db")?;
        // add info to balance table
        let mut st2 = conn.prepare("update balance set balance=? where account=?;")?;
        st2.bind(1, new_balance)?;
        st2.bind(2, u_name)?;
        st2.next()?;
        Ok(())
    }

    pub fn pay(&self, u_from: &str, u_to: &str, amount: i64) -> Result<(), UBaseErr> {
        let conn = sqlite::open("./data/users.db")?;
        let mut st = conn.prepare("insert into transactions (u_from, u_to, t_date, t_amount) values(?,?,datetime(\"now\"),?);")?;
        st.bind(1, u_from)?;
        st.bind(2, u_to)?;
        st.bind(3, amount)?;
        st.next()?;
        Ok(())
    }

    pub fn pay_with_verify(&self, u_from: &str, u_to: &str, amount: f64) -> Result<(), UBaseErr> {
        let conn = sqlite::open("./data/users.db")?;
        // get the balance from sender and receiver
        let balance_sender = self.get_balance(u_from);
        let balance_receiver = self.get_balance(u_to);
        // whether the sender has enough balance to pay?
        if balance_sender < amount {
            println!("Not enough money for {}'s payment.", u_from); // if no
        } else {
            // if yes
            // update the transaction table
            let mut st = conn.prepare("insert into transactions (u_from, u_to, t_date, t_amount) values(?,?,datetime(\"now\"),?);")?;
            st.bind(1, u_from)?;
            st.bind(2, u_to)?;
            st.bind(3, amount)?;
            st.next()?;
            // update the balance table
            let mut st_update_sender = conn.prepare("update balance set balance=? where account=?;")?;
            st_update_sender.bind(1, balance_sender - amount)?;
            st_update_sender.bind(2, u_from)?;
            st_update_sender.next()?;

            let mut st_update_receiver = conn.prepare("update balance set balance=? where account=?;")?;
            st_update_receiver.bind(1, balance_receiver + amount)?;
            st_update_receiver.bind(2, u_to)?;
            st_update_receiver.next()?;
        };
        Ok(())
    }

    pub fn get_balance(&self, account: &str) -> f64 {
        let mut balance = 0.0;
        let conn = sqlite::open("./data/users.db").unwrap();
        let mut st = conn
            .prepare("SELECT * FROM balance WHERE account = ?;").unwrap();
        st.bind(1, account);

        while let State::Row = st.next().unwrap() {
            let account_name = st.read::<String>(0).unwrap();
            if account == account_name {
                return st.read::<String>(1).unwrap().parse::<f64>().unwrap();
            }
        }
        balance
    }

    pub fn get_transaction_history(&self, u_name: &str) -> Result<(), UBaseErr> {
        // Establish the connection
        let conn = sqlite::open("./data/users.db").unwrap();

        // check the entry for selected "sender"
        let mut st_send = conn
            .prepare("SELECT * FROM transactions WHERE u_from = ?;").unwrap();
        st_send.bind(1, u_name);
        // print all results
        while let State::Row = st_send.next().unwrap() {
            let sender = st_send.read::<String>(0).unwrap();
            if u_name == sender {
                let u_from = sender;
                let u_to = st_send.read::<String>(1).unwrap();
                let time_stamp = st_send.read::<String>(2).unwrap();
                let amount = st_send.read::<String>(3).unwrap();
                println!("{} sent {} to {} on {}.", u_from, amount, u_to, time_stamp);
            }
        };

        // check the entry for selected "receiver"
        let mut st_rec = conn
            .prepare("SELECT * FROM transactions WHERE u_to = ?;").unwrap();
        st_rec.bind(1, u_name);
        // print all results
        while let State::Row = st_rec.next().unwrap() {
            let receiver = st_rec.read::<String>(1).unwrap();
            if u_name == receiver {
                let u_from = st_rec.read::<String>(0).unwrap();
                let u_to = receiver;
                let time_stamp = st_rec.read::<String>(2).unwrap();
                let amount = st_rec.read::<String>(3).unwrap();
                println!("{} received {} from {} on {}.", u_to, amount, u_from, time_stamp);
            }
        };
        Ok(())
    }
}


fn main() {
    let BankBase = UserBase {
        fname: String::from("./data/users.db"),
    };

    BankBase.clear_database();

    BankBase.add_user("Mike", "123456");
    BankBase.add_user("Jason", "123456");
    BankBase.add_user("Lin", "123456");

    BankBase.save_money("Mike", 500.0);
    BankBase.save_money("Jason", 100.0);
    BankBase.save_money("Lin", 200.0);

    BankBase.pay_with_verify("Mike", "Lin", 100.0); // Mike:400, Jason: 100, Lin:300
    BankBase.pay_with_verify("Jason", "Mike", 150.0); // Failed
    BankBase.pay_with_verify("Lin", "Mike", 50.0); // Mike:450, Jason: 100, Lin:250

    BankBase.get_transaction_history("Mike");
}

#[cfg(test)]
mod tests;

