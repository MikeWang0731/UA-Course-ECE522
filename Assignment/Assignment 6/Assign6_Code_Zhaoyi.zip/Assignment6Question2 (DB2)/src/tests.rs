#[test]
pub fn test_pay() {
    use super::*;
    use sqlite::State;

    let init_db = UserBase {
        fname: String::from("./data/users.db")
    };
    let conn = sqlite::open(&init_db.fname).unwrap();

    // init_db.clear_database(); // init the database
    // add user
    init_db.add_user(&String::from("Mike"), &String::from("123456"), 500.0);
    init_db.add_user(&String::from("Jason"), &String::from("123456"), 100.0);
    // make a payment
    init_db.pay_with_verify("Mike", "Jason", 100.0);
    // find the payment record
    let mut st = conn.prepare("select * from transactions where u_from = ?;").unwrap();
    st.bind(1, "Mike").unwrap();
    // whether the payment record is the same as what we expect
    while let State::Row = st.next().unwrap() {
        assert_eq!(String::from("Mike"), st.read::<String>(0).unwrap());
        assert_eq!(String::from("Jason"), st.read::<String>(1).unwrap());
        assert_eq!(String::from("100.0"), st.read::<String>(3).unwrap());
    };
}

