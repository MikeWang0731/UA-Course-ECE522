#[test]
pub fn basic_multiply() {
}
#[test]
pub fn multiply_negative_number() {
}
#[test]
pub fn multiply_random_numbers() {
}

#[test]
pub fn basic_divide() {
}
#[test]
pub fn divide_negative_number() {
}
#[test]
pub fn divide_random_numbers() {
}
   
